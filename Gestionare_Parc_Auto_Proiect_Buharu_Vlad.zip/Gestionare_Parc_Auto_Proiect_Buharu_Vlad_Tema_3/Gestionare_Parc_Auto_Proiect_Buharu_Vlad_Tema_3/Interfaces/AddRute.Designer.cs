﻿
namespace Gestionare_Parc_Auto_Proiect_Buharu_Vlad_Tema_3
{
    partial class AddRute
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancelRute = new System.Windows.Forms.Button();
            this.btnSaveRute = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFromRute = new System.Windows.Forms.TextBox();
            this.txtNameRute = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtToRute = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnCancelRute
            // 
            this.btnCancelRute.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelRute.Location = new System.Drawing.Point(276, 262);
            this.btnCancelRute.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancelRute.Name = "btnCancelRute";
            this.btnCancelRute.Size = new System.Drawing.Size(99, 35);
            this.btnCancelRute.TabIndex = 16;
            this.btnCancelRute.Text = "Cancel";
            this.btnCancelRute.UseVisualStyleBackColor = true;
            this.btnCancelRute.Click += new System.EventHandler(this.btnCancelRute_Click);
            // 
            // btnSaveRute
            // 
            this.btnSaveRute.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveRute.Location = new System.Drawing.Point(127, 262);
            this.btnSaveRute.Margin = new System.Windows.Forms.Padding(4);
            this.btnSaveRute.Name = "btnSaveRute";
            this.btnSaveRute.Size = new System.Drawing.Size(99, 35);
            this.btnSaveRute.TabIndex = 15;
            this.btnSaveRute.Text = "Save";
            this.btnSaveRute.UseVisualStyleBackColor = true;
            this.btnSaveRute.Click += new System.EventHandler(this.btnSaveRute_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 100);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 19);
            this.label2.TabIndex = 14;
            this.label2.Text = "Name";
            // 
            // txtFromRute
            // 
            this.txtFromRute.Location = new System.Drawing.Point(123, 129);
            this.txtFromRute.Margin = new System.Windows.Forms.Padding(4);
            this.txtFromRute.Name = "txtFromRute";
            this.txtFromRute.Size = new System.Drawing.Size(231, 20);
            this.txtFromRute.TabIndex = 13;
            // 
            // txtNameRute
            // 
            this.txtNameRute.Location = new System.Drawing.Point(123, 99);
            this.txtNameRute.Margin = new System.Windows.Forms.Padding(4);
            this.txtNameRute.Name = "txtNameRute";
            this.txtNameRute.Size = new System.Drawing.Size(231, 20);
            this.txtNameRute.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(141, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 31);
            this.label1.TabIndex = 11;
            this.label1.Text = "Add Rute";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(24, 129);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 19);
            this.label3.TabIndex = 17;
            this.label3.Text = "From";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(24, 157);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 19);
            this.label4.TabIndex = 19;
            this.label4.Text = "To";
            // 
            // txtToRute
            // 
            this.txtToRute.Location = new System.Drawing.Point(123, 157);
            this.txtToRute.Margin = new System.Windows.Forms.Padding(4);
            this.txtToRute.Name = "txtToRute";
            this.txtToRute.Size = new System.Drawing.Size(231, 20);
            this.txtToRute.TabIndex = 18;
            // 
            // AddRute
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 340);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtToRute);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnCancelRute);
            this.Controls.Add(this.btnSaveRute);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtFromRute);
            this.Controls.Add(this.txtNameRute);
            this.Controls.Add(this.label1);
            this.Name = "AddRute";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddRute";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCancelRute;
        private System.Windows.Forms.Button btnSaveRute;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFromRute;
        private System.Windows.Forms.TextBox txtNameRute;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtToRute;
    }
}