﻿
namespace Gestionare_Parc_Auto_Proiect_Buharu_Vlad_Tema_3
{
    partial class AddDrivers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtFirstNameDriver = new System.Windows.Forms.TextBox();
            this.txtSecondNameDriver = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtBirthDayDriver = new System.Windows.Forms.DateTimePicker();
            this.txtAdressDriver = new System.Windows.Forms.TextBox();
            this.btnSaveDriver = new System.Windows.Forms.Button();
            this.btnCancelDriver = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txtSalaryDriver = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(184, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Add Driver";
            // 
            // txtFirstNameDriver
            // 
            this.txtFirstNameDriver.Location = new System.Drawing.Point(190, 63);
            this.txtFirstNameDriver.Margin = new System.Windows.Forms.Padding(4);
            this.txtFirstNameDriver.Name = "txtFirstNameDriver";
            this.txtFirstNameDriver.Size = new System.Drawing.Size(322, 26);
            this.txtFirstNameDriver.TabIndex = 1;
            // 
            // txtSecondNameDriver
            // 
            this.txtSecondNameDriver.Location = new System.Drawing.Point(190, 101);
            this.txtSecondNameDriver.Margin = new System.Windows.Forms.Padding(4);
            this.txtSecondNameDriver.Name = "txtSecondNameDriver";
            this.txtSecondNameDriver.Size = new System.Drawing.Size(322, 26);
            this.txtSecondNameDriver.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(44, 67);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "First Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(44, 105);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 19);
            this.label3.TabIndex = 4;
            this.label3.Text = "Second Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(44, 148);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 19);
            this.label4.TabIndex = 5;
            this.label4.Text = "Birth date";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(44, 181);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 19);
            this.label5.TabIndex = 6;
            this.label5.Text = "Adress";
            // 
            // txtBirthDayDriver
            // 
            this.txtBirthDayDriver.Location = new System.Drawing.Point(190, 139);
            this.txtBirthDayDriver.Margin = new System.Windows.Forms.Padding(4);
            this.txtBirthDayDriver.MaxDate = new System.DateTime(2003, 1, 1, 0, 0, 0, 0);
            this.txtBirthDayDriver.Name = "txtBirthDayDriver";
            this.txtBirthDayDriver.Size = new System.Drawing.Size(322, 26);
            this.txtBirthDayDriver.TabIndex = 7;
            this.txtBirthDayDriver.Value = new System.DateTime(2003, 1, 1, 0, 0, 0, 0);
            // 
            // txtAdressDriver
            // 
            this.txtAdressDriver.Location = new System.Drawing.Point(190, 177);
            this.txtAdressDriver.Margin = new System.Windows.Forms.Padding(4);
            this.txtAdressDriver.Name = "txtAdressDriver";
            this.txtAdressDriver.Size = new System.Drawing.Size(322, 26);
            this.txtAdressDriver.TabIndex = 8;
            // 
            // btnSaveDriver
            // 
            this.btnSaveDriver.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveDriver.Location = new System.Drawing.Point(235, 305);
            this.btnSaveDriver.Margin = new System.Windows.Forms.Padding(4);
            this.btnSaveDriver.Name = "btnSaveDriver";
            this.btnSaveDriver.Size = new System.Drawing.Size(99, 35);
            this.btnSaveDriver.TabIndex = 9;
            this.btnSaveDriver.Text = "Save";
            this.btnSaveDriver.UseVisualStyleBackColor = true;
            this.btnSaveDriver.Click += new System.EventHandler(this.btnSaveDriver_Click);
            // 
            // btnCancelDriver
            // 
            this.btnCancelDriver.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelDriver.Location = new System.Drawing.Point(384, 305);
            this.btnCancelDriver.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancelDriver.Name = "btnCancelDriver";
            this.btnCancelDriver.Size = new System.Drawing.Size(99, 35);
            this.btnCancelDriver.TabIndex = 10;
            this.btnCancelDriver.Text = "Cancel";
            this.btnCancelDriver.UseVisualStyleBackColor = true;
            this.btnCancelDriver.Click += new System.EventHandler(this.btnCancelDriver_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(44, 217);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 19);
            this.label6.TabIndex = 11;
            this.label6.Text = "Salary";
            // 
            // txtSalaryDriver
            // 
            this.txtSalaryDriver.Location = new System.Drawing.Point(190, 210);
            this.txtSalaryDriver.Name = "txtSalaryDriver";
            this.txtSalaryDriver.Size = new System.Drawing.Size(322, 26);
            this.txtSalaryDriver.TabIndex = 12;
            // 
            // AddDrivers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(554, 353);
            this.Controls.Add(this.txtSalaryDriver);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnCancelDriver);
            this.Controls.Add(this.btnSaveDriver);
            this.Controls.Add(this.txtAdressDriver);
            this.Controls.Add(this.txtBirthDayDriver);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtSecondNameDriver);
            this.Controls.Add(this.txtFirstNameDriver);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "AddDrivers";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddDrivers";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFirstNameDriver;
        private System.Windows.Forms.TextBox txtSecondNameDriver;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker txtBirthDayDriver;
        private System.Windows.Forms.TextBox txtAdressDriver;
        private System.Windows.Forms.Button btnSaveDriver;
        private System.Windows.Forms.Button btnCancelDriver;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtSalaryDriver;
    }
}